
Assume foxy is the angle from top screen to bottom screen and usually we use fovy/2
